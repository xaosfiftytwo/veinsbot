"""This class should provide further parsing functions for games. It also
provides the style12 parsing function. Please note that some information can
come together with style 12 that is mostly unrelated (if it is your game it can
include the gin notification). The function returns "spam", which might be split
on \\n and chunks send to IcsBot.parse_block to make sure that all is good.
"""

import re
import icsbot.misc.regex as _regex

def style12(data):
    """Process style 12 output, data can either be a match object (of the regex
    in icsbot.misc.regex) or a string.
    
    ep_file can be None,
    ep_square will be "-" then.
    
    Check dict returned for all the stuff it gets.
    """
    if type(data) is str or type(data) is unicode:
        matches = _regex.STYLE12_re.match(data)
    else:
        matches = data
    
    if not matches:
        print 'no matches'
        return
    
    d = matches.groupdict()
    
    fen = d['position'].strip()
    fen = fen.replace(' ', '/')

    r = re.compile('(-+)')

    l = r.split(fen)
    for i in xrange(1, len(l),2):
        l[i] = str(len(l[i]))
    fen = ''.join(l)
    
    d['fen_pos'] = fen
    
    if d['move_san'] == 'none':
        d['move_san'] = None
    
    if d['move_coord'] == 'none':
        d['move_coord'] = None
    
    files = {'-1':None, '0':'a', '1':'b', '2':'c', '3':'d', '4':'e', '5':'f', '6':'g', '7':'h'}
    d['ep_file'] = files[d['ep_file']]
    if d['ep_file']:
        d['ep_square'] = d['ep_file'] + ('6' if d['to_move'] == 'B' else '3')
    else:
        d['ep_square'] = '-'
    
    castles = ''
    
    d['w_k_castle'] = int(d['w_k_castle'])
    d['w_q_castle'] = int(d['w_q_castle'])
    d['b_k_castle'] = int(d['b_k_castle'])
    d['b_q_castle'] = int(d['b_q_castle'])
    
    if d['w_k_castle']:
        castles += 'K'
    if d['w_q_castle']:
        castles += 'Q'
    if d['b_k_castle']:
        castles += 'k'
    if d['b_q_castle']:
        castles += 'q'
    if castles == '':
        castles = '-'
    
    d['fen'] = fen + ' %s %s %s %s %s' % (d['to_move'].lower(), castles, d['ep_square'], d['irr_ply'], d['move_num'])
    
    
    
    return d


def GameInfo(object):
    """The class registeres with bot['games'] and fills them with information
    from style 12. Right now parsing is only supported for:
        WORK IN PROGRESS
    """
    def __init__(self, icsbot):
        pass
