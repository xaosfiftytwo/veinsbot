#!/usr/bin/env python
#-*- coding:utf-8 -*-

"""Gamebot for retrieving games from the ficsgames db on the base of the icsbot package.
"""

# If I rmatch observatoer, etc.
superexamine = True

import time
import sys
import os
import re
import copy
import pytz, datetime
import array

import icsbot
import icsbot.status
import icsbot.parser.moves
import icsbot.parser.gamelist
from icsbot.parser.game_info import style12
from icsbot.misc.tells import parse
from icsbot.misc import pgn

import MySQLdb

# Timezone shit:

utc = pytz.timezone('UTC')
server_time = pytz.timezone('America/Los_Angeles')

bot_operators = set(['ludens', 'seberg', 'bottest'])

def mk_servertime(dt):
    # dunno a better way then converting back and forth rigth now.
    tim = dt.utctimetuple()
    tim = datetime.datetime(tim[0], tim[1], tim[2], tim[3], tim[4], tim[5], tzinfo=utc)
    return tim.astimezone(server_time)

tells_file = file('tell.log', 'a')
def tell_logger(tell):
    tells_file.write(time.strftime('%d-%m %H:%M: ', time.localtime()) + ': ' +  tell)
    tells_file.flush()

def formatlargeint(x):
    ## Mit so einem Wurst Perl kann doch niemand was anfangen :))
    #return re.sub(r'(\d{3})(?=\d)', r'\1,', str(x)[::-1])[::-1]
    # 4 Extra zeilen, 4x so schnell ^^ und vieel übersichtlicher *hust*
    x = str(x);l = len(x)
    off = l % 3
    r = [x[:off]] if off != 0 else []
    r.extend([x[off+3*n:off+3*n+3] for n in xrange(l//3)])
    return ','.join(r)

class Log(object):
    def __init__(self, location):
        self.buf = ''
        self.errors = file(location, 'a')
    
    def write(self, output):
        out = str(output).split('\n')
        out[0] = self.buf + out[0]
        self.buf = out[-1]
        for spam in out[:-1]:
            self.errors.write(time.strftime('\n%d-%m %H:%M: ', time.localtime()) +  str(spam))
        
        self.errors.flush()

errors = Log('gamebot.log')

sys.stderr = errors
#sys.stdout = errors

errors.write('')
print ''
print 'Session start.'

mysql_log = Log('gamebot_mysql_err.log')

def retry_once(func):
    # expects a class function.
    def new_func(self, *args, **kwargs):
        try:
            return func(self, *args, **kwargs)
        except MySQLdb.Error, e:
            mysql_log.write('MySQL error %d: %s\n' % (e.args[0], e.args[1]))
            print 'MySQL error %d: %s\n' % (e.args[0], e.args[1])
        self.__init__()
        mysql_log.write('Reconnected to MySQL fine, trying query again.')
        print 'Reconnected to MySQL fine, trying query again.'
        try:
            return func(self, *args, **kwargs)
        except MySQLdb.Error, e:
            mysql_log.write('2nd try: MySQL error %d: %s\n' % (e.args[0], e.args[1]))
            print '2nd try: MySQL error %d: %s\n' % (e.args[0], e.args[1])
            raise MySQLdb.Error, e
        
        mysql_log.write('Successfully recovered.')
        print 'Successfully recovered'
    
    return new_func


class Mysql:
    def __init__(self, database = 'ficsgames', mysql_server='localhost', username ='ficsgamesread', password='3A!u=rAPH+3u'):
        self.username = username
        self.password = password
        self.server = mysql_server
        self.database = database

        self.conn = MySQLdb.connect(host = self.server,
                            user = self.username,
                            passwd = self.password,
                            db = self.database)
        
        self.cursor = self.conn.cursor()
        self.dcursor = self.conn.cursor(MySQLdb.cursors.DictCursor)

        #connection established
        self.connection = True
        
        self.cursor.execute('SET time_zone = "UTC"')
        self.dcursor.execute('SET time_zone = "UTC"')
        
        self.conn.autocommit(True)
       
    @retry_once 
    def insert(self, sql, *args):
        self.cursor.execute(sql, args)
        return int(self.conn.insert_id())

    @retry_once
    def select(self, sql, *args):
        self.dcursor.execute(sql, args)
        return self.dcursor.fetchall()

    @retry_once
    def fetchone(self, sql, *args):
        self.dcursor.execute(sql, args)
        return self.dcursor.fetchone()

    @retry_once
    def execute(self, sql, *args):
        self.dcursor.execute(sql, args)
        return self.dcursor

# Main loop in case of disconnections, just recreating the bot right now.
# Should not actually be necessary.
while True:
    db = Mysql()

    bot = icsbot.IcsBot(tell_logger=tell_logger, interface='gamebot 2.0.1')
    
    bot.send('iset movecase 1')
    bot.send('iset compressmove 1')
    bot.send('set style 12')
    if superexamine == True:
        bot.send('set examine 1')

    # to know who is a shitty guest.
    icsbot.status.Status(bot)
    
    users = bot['users']
    variants = bot['variants']
    buffer_vars = set()


    _previous_total = None
    def update_finger(timer=False):
        global _previous_total
        new = db.select('SELECT sum(count) FROM variants WHERE varianttext!="bughouse" and varianttext!="guestgames"')[0]['sum(count)']
        bot.send('set 1 GameBot keeps track of all games played on FICS. It stores all except bughouse and guest games. It has stored %s games so far.' % formatlargeint(new))
        if _previous_total and new // 1000000 > _previous_total // 1000000:
            bot.send('cshout GameBot has now saved %s million games! "finger GameBot" or "tell gamebot help" for more information.' % (new // 1000000))
        _previous_total = new
        if timer is True:
            bot.timer(time.time()+1800, update_finger, timer=True)
    
    bot.timer(time.time(), update_finger, timer=True)


    def load_variant_id(variant, item):
        info = db.select('SELECT * FROM variants WHERE VARIANTTEXT=%s', variant['handle'])
        if not info:
            return
        
        variant['ID'] = info[0]['ID']
        buffer_vars.add(variant)
    
    def load_id(usr, item):
        info = db.select('SELECT * FROM handles WHERE HANDLETEXT=%s', usr['handle'])
        if not info:
            return
        usr['ID'] = info[0]['ID']
    
    variants.register('ID', load_variant_id, loader=True)     
    users.register('ID', load_id, loader=True)
    
    
    operators = ['>=', '<=', '=', '<', '>', '']
    
    def setup_query(usr, args='', parsed=False, query_type='history'):
        """Called by history, maybe later more to set up the query.
        """
        
        # ID for which we will ignore the games in case new were added.
        # Gets set after history is sent.
        usr['query'] = None
        usr['query_end'] = None
        usr['query_type'] = query_type
        usr['query_offset'] = 0
        # array of doubles to translate each offset to an end_time.
        t = time.gmtime()
        usr['query_offsets'] = [datetime.datetime(t[0], t[1], t[2], t[3], t[4], t[5], tzinfo=utc)]
        usr['query_offset_ids'] = [2**61-1]
        
        # (RE)SET EVERYTHING, don't feel like iffing if it exists.:
        offset = 0
        player1_id = None
        player2_id = None
        vs = None
        time_op = None
        gtime = None
        inc_op = None
        inc = None
        colour = None
        rated = None
        result = None
        pscore = None
        result = None
        opp_rating_op = None
        opp_rating = None
        wrating_op = None
        wrating = None
        brating_op = None
        brating = None
        date_op = None
        date = None
        ply_op = None
        ply  = None
        

        # FIRST WE HAVE TO PARSE ALL THIS CRAP:
        if parsed:
            args, flags = parsed
        else:
            args, flags = parse(args)
        
        if query_type == 'history':
            if args:
                player1 = users[args[0]]
                player1_id = player1['ID']
            else:
                player1 = usr
                player1_id = usr['ID']
            if player1_id is None:
                return bot.qtell(usr, 'The player %s is not in my database.' % player1)
        
            usr['history_player'] = player1
        
        if query_type == 'history' and flags.has_key('o') and len(flags['o']) != 0:
            player2 = users[flags['o'][0]]
            player2_id = player2['ID']
            if player2_id is None:
                return bot.qtell(usr, 'The player %s is not in my database.' % usr)
                
        if flags.has_key('v'):
            vs = set()
            for i in xrange(len(flags['v'])):
                if flags['v'][i] == 'chess':
                    vs.add(variants['lightning']['ID'])
                    vs.add(variants['blitz']['ID'])
                    vs.add(variants['standard']['ID'])
                    vs.add(variants['untimed']['ID'])
                else:
                    v = variants[flags['v'][i]]['ID']
                    if v is None:
                        return bot.qtell(usr, 'The variant %s was not recognized.' % flags['v'][i])
                    vs.add(v)
            # If its empty, I want it to be None. To keep checks in mk_query similar
            if not vs:
                vs = None
                
        if flags.has_key('t') and len(flags['t']) != 0:
            t = ''.join(flags['t'])
            # operators are sorted to check for >= and <= first.
            # As I include "" as an operator, this always has to be successfull.
            for op in operators:
                if t.startswith(op):
                    t = t.lstrip(op)
                    try:
                        t = int(t)
                    except:
                        return bot.qtell(usr, 'The time "%s" cannot be converted to an ineger. (A correct operator would be stripped)' % t)
                    if op == '':
                        op = '='
                    time_op = op
                    gtime = t
                    break


        if flags.has_key('inc') and len(flags['inc']) != 0:
            inc = ''.join(flags['inc'])
            # see above
            for op in operators:
                if inc.startswith(op):
                    inc = inc.lstrip(op)
                    try:
                        inc = int(inc)
                    except:
                        return bot.qtell(usr, 'The increment "%s" cannot be converted to an ineger. (A correct operator would be stripped)' % inc)
                    if op == '':
                        op = '='
                    inc_op = op
                    inc = inc
                    break
        
        # Due to how the query is created, the query_type check is unnecessary,
        # but it can't hurt.
        if query_type == 'history' and flags.has_key('w'):
            colour = 'w'
        elif query_type == 'history' and flags.has_key('b'):
            colour = 'b'
        
        if flags.has_key('r'):
            rated = True
        elif flags.has_key('u'):
            rated = False
        
        
        if flags.has_key('result') and len(flags['result']) != 0:
            r = flags['result'][0]
            if r == '1-0':
                result = 1
            elif r == '0-1':
                result = 0
            elif r == '1/2-1/2' or r == '1/2' or r == '=':
                result = 0.5
            elif r == '+':
                pscore = 1
            elif r == '-':
                pscore = 0
            else:
                return bot.qtell(usr, 'Invalid result %s' % r)
        
        # Opp rating can only be given with a history.
        if query_type=='history' and flags.has_key('or') and len(flags['or']) != 0:
            r = ''.join(flags['or'])
            # see above
            for op in operators:
                if r.startswith(op):
                    r = r.lstrip(op)
                    try:
                        r = int(r)
                    except:
                        return bot.qtell(usr, 'The rating "%s" cannot be converted to an integer. (A correct operator would be stripped)' % r)
                    if op == '':
                        op = '='
                    opp_rating_op = op
                    opp_rating = r
                    break
        
        if query_type=='show' and flags.has_key('wr') and len(flags['wr']) != 0:
            r = ''.join(flags['wr'])
            # see above
            for op in operators:
                if r.startswith(op):
                    r = r.lstrip(op)
                    try:
                        r = int(r)
                    except:
                        return bot.qtell(usr, 'The rating "%s" cannot be converted to an integer. (A correct operator would be stripped)' % r)
                    if op == '':
                        op = '='
                    wrating_op = op
                    wrating = r
                    break
        
        if query_type=='show' and flags.has_key('br') and len(flags['br']) != 0:
            r = ''.join(flags['br'])
            # see above
            for op in operators:
                if r.startswith(op):
                    r = r.lstrip(op)
                    try:
                        r = int(r)
                    except:
                        return bot.qtell(usr, 'The rating "%s" cannot be converted to an integer. (A correct operator would be stripped)' % r)
                    if op == '':
                        op = '='
                    brating_op = op
                    brating = r
                    break
       
       
        if flags.has_key('ply') and len(flags['ply']) != 0:
            ply = ''.join(flags['ply'])
            # see above
            for op in operators:
                if ply.startswith(op):
                    ply = ply.lstrip(op)
                    try:
                        ply = int(ply)
                    except:
                        return bot.qtell(usr, 'The ply "%s" cannot be converted to an integer. (A correct operator would be stripped)' % ply)
                    if op == '':
                        op = '='
                    ply_op = op
                    ply = ply
                    break
        
        
        if flags.has_key('d') and len(flags['d']) != 0:
            d = ' '.join(flags['d'])
            
            # see above
            for op in operators:
                if d.startswith(op):
                    d = d.lstrip(op)
                    d = d.strip()
                    try:
                        t = time.strptime(d, '%Y-%m-%d %H:%M')
                    except:
                        try:
                            t = time.strptime(d, '%Y-%m-%d')
                        except:
                            return bot.qtell(usr, 'The date "%s" cannot be converted.' % d)
                    
                    d = datetime.datetime(t[0], t[1], t[2], t[3], t[4], t[5], tzinfo=server_time)
                    d = server_time.normalize(d)
                    d = d.astimezone(utc)
                    # don't feel like having mysql module handle it here.
                    d = d.strftime('"%Y-%m-%d %H:%M:%S"')
                    
                    if op == '':
                        op = '='
                    date_op = op
                    date = d
                    break
        
        if flags.has_key('s') and len(flags['s']) != 0:
            s = flags['s'][0]
            try:
                s = float(s)
            except:
                return bot.qtell(usr, 'Could not convert number of days to skip "%s" to a number' % s)
            usr['query_offsets'][0] += datetime.timedelta(-s)
            
        
        # AND NOW, LET US BEGIN THE FUN OF CREATING BIG TIME QUERIES!
        # hab keine lust die ganzen SQL zeugs zu benutzten. Es sind alles Zahlen
        # und damit ists sicher.  
        
        # We need to group variant + users into unions to give mysql some hints
        # as to how efficiently execute the query, as such all combinations of
        # these will be inside of one union.
        unions = []
        if vs is not None:
            for var in vs:
                unions.append(['variant=%s' % var])
        
        if unions == []:
            unions = [[]]
        
        if colour != 'b' and colour != 'w':
            unions = unions * 2
        
        for i in xrange(len(unions)):
            # mutable objects ...
            unions[i] = copy.copy(unions[i])
            
            # Mysql can figure out which handle to use inside the query is faster,
            # Anyways usually we shouldn't have two, as this is slow.
            
            # Colour/player dependend stuff:
            if (i % 2 == 0 and colour is None) or colour == 'w':
                if player1_id is not None:
                    unions[i].append('whandle=%s' % player1_id)
                if player2_id is not None:
                    unions[i].append('bhandle=%s' % player2_id)
                if opp_rating is not None:
                    unions[i].append('brating%s%s' % (opp_rating_op, opp_rating))
                if pscore is not None:
                    unions[i].append('result=%s' % pscore)
            elif (i % 2 == 1 and colour is None) or colour == 'b':
                if player1_id is not None:
                    unions[i].append('bhandle=%s' % player1_id)
                if player2_id is not None:
                    unions[i].append('whandle=%s' % player2_id)               
                if opp_rating is not None:
                    unions[i].append('wrating%s%s' % (opp_rating_op, opp_rating))
                if pscore is not None:
                    unions[i].append('result=%s' % abs(pscore-1))
            
            # Independend:
            if date is not None:
                # %f is important here, %s would round off a bit.
                unions[i].append('end_time%s%s' % (date_op, date))
            
            if result is not None:
                unions[i].append('result=%s' % result)
            
            if wrating is not None:
                unions[i].append('wrating%s%s' % (wrating_op, wrating))

            if brating is not None:
                unions[i].append('brating%s%s' % (brating_op, brating))

            if ply is not None:
                unions[i].append('plys%s%s' % (ply_op, ply))
            
            if rated is True:
                unions[i].append('rated=1')
            elif rated is False:
                unions[i].append('rated=0')
            
            if gtime is not None:
                unions[i].append('time%s%s' % (time_op, gtime))
            if inc is not None:
                unions[i].append('inc%s%s' % (inc_op, inc))
            
            # lets create the union query:
            if unions[i]:
                unions[i] = 'SELECT %(columns)s FROM games LEFT JOIN handles as white ON white.ID=whandle LEFT JOIN handles as black ON black.ID=bhandle LEFT JOIN variants ON variants.ID=variant LEFT JOIN longresults ON longresults.ID=games.longresult LEFT JOIN moves ON moves.ID=games.ID WHERE ' + ' and '.join(unions[i]) + ' and end_time<=%(ignore_time)s and games.ID<%(ignore_id)s ORDER BY end_time DESC, ID DESC LIMIT %(number)s'            
        
        
        unions = filter(None, unions)
        if not unions:
            # usr ran show without any options ...
            usr['query'] = 'SELECT %(columns)s FROM games USE INDEX (`end_time+id`, `variant+time+id`) LEFT JOIN handles as white ON white.ID=whandle LEFT JOIN handles as black ON black.ID=bhandle LEFT JOIN variants ON variants.ID=variant LEFT JOIN longresults ON longresults.ID=games.longresult LEFT JOIN moves ON moves.ID=games.ID WHERE end_time<=%(ignore_time)s and games.ID<%(ignore_id)s ORDER BY end_time DESC, ID DESC LIMIT %(offset)s, %(number)s'
            return True
        usr['query'] = '(' + ') UNION ('.join(unions) + ') ORDER BY end_time DESC, ID DESC LIMIT %(offset)s, %(number)s'
        
        return True
        

    def mk_query(usr, columns='*', number=1, offset=0, ignore_time_limit=False):
        """Grab data, This returns either (True, data) or (False, error), where
        error is a qtell object, so return it.
        
        NOTE: Right now this expects that there were NO jumps in the dataset,
            it will return an error otherwise.
            
        ERROR CODES:
            True: All fetched fine
            False: Some error, please return my data for user
            -1: Not all rows fetched due to timeout of 5 seconds.
        """
        # Add 5 second grace.
        if usr['blocked_until'] > time.time() + 5:
            return (False, bot.qtell(usr, 'You are blocked from executing a query for another %2.1f seconds. This might be just bad luck or a really slow query you just did. Please make sure to not do slow queries often, or we might have to disable them.' % (usr['blocked_until'] - time.time())))
        
        start_offset = offset
        length = len(usr['query_offsets'])
        
        if usr['query_end'] and offset > usr['query_end']:
            return (False, bot.qtell(usr, 'You are at the end of the list.'))
        
        if length-1 < offset:
            return (False, bot.qtell(usr, 'You cannot jump in the dataset, you have to view a continuous history. Use the end_time -d flag to view older games.'))

        ignore_time = usr['query_offsets'][-1].strftime('"%Y-%m-%d %H:%M:%S"')
        ignore_id = usr['query_offset_ids'][-1]
        data = []
        t = time.time()
        # For these we already know the exact position, so fetching is easy.
        for i in xrange(start_offset, min(length-1, start_offset+number)):
            new = db.select('SELECT %s FROM games LEFT JOIN handles as white ON white.ID=whandle LEFT JOIN handles as black ON black.ID=bhandle LEFT JOIN variants ON variants.ID=variant LEFT JOIN longresults ON longresults.ID=games.longresult LEFT JOIN moves ON moves.ID=games.ID WHERE games.ID=%s' % (columns, usr['query_offset_ids'][i+1]))
            data.append(new[0])
            ignore_time = new[0]['end_time'].strftime('"%Y-%m-%d %H:%M:%S"')
            ignore_id = new[0]['ID']
        
        # As those above must be pretty fast, lets not really check there about hitting time limit.
        if length-1 < start_offset+number:
            offset = 0
            number = number - (length -1) + start_offset
            cursor = db.execute(usr['query'] % locals())
            while t + 5 > time.time() or ignore_time_limit:
                new = cursor.fetchone()
                if not new:
                    break
                data.append(new)
                usr['query_offsets'].append(new['end_time'].replace(tzinfo=utc))
                usr['query_offset_ids'].append(new['ID'])
            else:
                usr['blocked_until'] = time.time() + 50
                return (-1, data)
        
        if len(data) < number:
            usr['query_end'] = start_offset + len(data)
        
        dt = time.time()-t
        print 'Data selection for %s took about %s seconds' % (usr['handle'], dt)
        
        usr['query_time'] = dt
        usr['blocked_until'] = time.time() + 10 * dt - 5
        
        return (True, data)

    @bot.deco_tell('history')
    def history(usr, args, tags):
        """HISTORY
        =======
        
        history player [-v variant1 [variant2 ...]] [-o opponent] [-t [<|>][=]#]
        -inc [<|>][=]# [] [-w|-b] [-or [<|>][=]#] -d [<|>][=]yyyy-mm-dd [hh:mm]
        -result (+|-|=) -ply [<|>][=]# [-r|-u]
        
        Show the 20 most recently stored games that fit, the only difference to
        server is not showing ECO and ratings being before the game and not after.
        The options/flags are more exactly:
            o -v Variants seperated by spaces, at the moment, this has to be
                typed out, ie: -v standard wild/fr crazyhouse
            o -o opponent: The opponent for player (player defaults to you)
            o -t  [<|>][=]#: Limit on the starting time, ie: -t >=30 would give
                 games with a starting time of more or equal 30 minutes.
            o -inc [<|>][=]#: Limit on the increment, ie: -inc <5 would give only
                games with 0-4 second increments.
            o -w/-b If one of them is given, player has to be white/black.
            o -r/-u Filter to only show rated/unrated games.
            o -result result of the game, either:
                o 1-0; 0-1; 1/2-1/2 or 1/2
                o or +; = or -. In this case it is player1 wins/draws/loses.   
            o -or [<|>][=]#: The opponents rating, ie: -r >1800 to only get games
                where the opponent was rated more then 1800.
            o -d [<|>]yyyy-mm-dd [hh:mm] The end date (and time) of the game,
                ie -d >2008-10-12 to get only games after that date. hh:mm is not
                necessary. CAREFUL: If no minutes are given 00:00
                is assumed. Thus the = operator is useless (though possible)
            o -s Number of days to skip from history view.
            o -ply [<|>][=] Number of half moves played in the game.
        
        PLEASE NOTE: Some of these searches can be VERY slow, I will save if you
            did a slow query and block you for a while then. Queries that are
            VERY fast are generally:
                o Variants (unless you specify extremely many)
                o Time offsets to view old games
                o Everything else is fast if it is common, ie if you do -r or
                    result search, that will be OK, because all results are
                    rather common, if look for unrated games with t>800 then you
                    are likely to not get a result at all.
        
        To see more then the 20 most recently stored games, you can go through
        with next. To go back far, use a timeoffset (-d). An offset of n games cannot
        be provided for performance reasons.
        
        EXAMPLES
        ========
            o history Ludens
            o history Ludens -v blitz lightning -r >1800
            o ...
            
        NOTES:
        Useless input, ie -o -v standard (no opponent given) is mostly quietly
        ignored.
        More flags may be added, or flag meaning changed in the future. Also,
        a new game added to the database will not affect the behaviour until
        the history command is run again.
        """
        setup = setup_query(usr, args)
        if setup != True:
            # There is something wrong and we need to return the error to user.
            return setup
        return mk_hist(usr, first=True)


    @bot.deco_tell('show')
    def show(usr, args, tags):
        """SHOW 
        ====
        
        show variant
        
        Show the 20 most recently stored games in the specified variant(s).
        
        To see more then the 20 most recently stored games, you can go through
        with next. To see old games use the -d < YYYY-MM-DD option.
        
        EXAMPLES
        ========
            o show blitz
            o show crazyhouse -wr >2000 -result 0-1
        
        This command understands (non player specific) arguments of history as well,
        so please view help history.
        It supports additionally -wr [>|<][=]white_rating and -br [>|<][=]black_rating,
        which work as -or for history.
        """
        
        args, flags = parse(args)
        
        if flags.has_key('v'):
            flags['v'].extend(args)
        else:
            flags['v'] = args
        
        spam = setup_query(usr, parsed=([], flags), query_type='show')
        if spam != True:
            return spam
        
        return mk_show(usr, first=True)


    @bot.deco_tell('scroll')
    def scroll(usr, args, tags):
        """SCROLL
        =====
        
        scroll #, scroll number of days, ie:
            o scroll -20 -> scrolls 20 days back
            o scroll 20 -> scrolls 20 days forward
            
        This command changes the current history/show offset. Numbers will stay valid.
        Note that history/show numbers are truncated to 3 digits, keep that in mind if 
        you scroll past 1000.
        """
        s = args.split()
        if len(s) == 0:
            return bot.qtell(usr, 'You must give a positive/negative number of days to scroll.')
        try:
            i = float(s[0])
        except:
            return bot.qtell(usr, 'Could not convert %s to number' % s)
        
        if usr['query'] is None:
            return bot.qtell(usr, 'You do not have an active games history to scroll in.')
        
        if usr['blocked_until'] > time.time():
            return (False, bot.qtell(usr, 'You are blocked from executing a query for another %s seconds. This might be just bad luck or a really slow query you just did. Please make sure to not do slow queries often, or we might have to disable them.' % (usr['blocked_until'] - time.time())))
        
        # 4711
        #print 'DEBUG: %s' % usr['query_offsets']
        
        if len(usr['query_offsets']) == 1:
        	usr['query'] = None
        else:
        	usr['query_offsets'] = [usr['query_offsets'][-1] + datetime.timedelta(-i)]
        
        t = time.gmtime()
        d = datetime.datetime(t[0], t[1], t[2], t[3], t[4], t[5], tzinfo=utc)
        if usr['query_offsets'][0] > d:
            usr['query_offsets'] = [d]
            
        usr['query_offset_ids'] = [2**61-1]        
        usr['query_offset'] = 0
    
        return refresh(usr, args, tags)
        

    @bot.deco_tell('refresh')
    def refresh(usr, args, tags):
        """Print current history/show view (again).
        """
        if usr['query'] is None:
            return bot.qtell(usr, 'You have currently no history to print again, use the history command.')
        if usr['query_type'] == 'history':
            return mk_hist(usr, offset_add=0)    
        elif usr['query_type'] == 'show':
            return mk_show(usr, offset_add=0)
        else:
            return bot.qtell(usr, 'You just found a bug.')


    def mk_hist(usr, first=False, offset_add=20):
        if not first:
            usr['query_offset'] += offset_add
        success, data = mk_query(usr, columns='games.ID as ID, white.handletext as white, black.handletext as black, whandle, wrating, brating, rated, variants.showtext as variant, result, end_time, time, inc, longresults.showtext as lresult', number=21, offset=usr['query_offset'])
        
        if success == False:
            if not first:
                usr['query_offset'] -= offset_add
            return data
        
        if not data:
            if not first:
                usr['query_offset'] -= offset_add
            return bot.qtell(usr, 'There are no more games to show.')
        
        to_send = ['History for %s starting at game %s:' % (usr['history_player'], usr['query_offset']+1)]
        to_send.append('                   Opponent        Typ          End Date')
        wscore = {1:'+', .5:'=', 0:'-'}
        bscore = {1:'-', .5:'=', 0:'+'}
        rated = {1:'r', 0:'u'}
        for i, g in enumerate(data[:20]):
            if g['whandle'] == usr['history_player']['ID']:
                to_send.append('%3s: %s %4s W %4s %-14s [%3s%s%3s %3s] %3s %s' % (str(i+1+usr['query_offset'])[-3:], wscore[g['result']], g['wrating'], g['brating'], str(g['black'])[:14], g['variant'], rated[g['rated']], g['time'], g['inc'], g['lresult'], mk_servertime(g['end_time']).strftime('%a %b %d, %H:%M %Z %Y')))
            else:
                to_send.append('%3s: %s %4s B %4s %-14s [%3s%s%3s %3s] %3s %s' % (str(i+1+usr['query_offset'])[-3:], bscore[g['result']], g['brating'], g['wrating'], str(g['white'])[:14], g['variant'], rated[g['rated']], g['time'], g['inc'], g['lresult'], mk_servertime(g['end_time']).strftime('%a %b %d, %H:%M %Z %Y')))
        
        if len(data) == 21 or len(data) == 20 and success == -1:
            to_send.append('Use "tell %s next" to view more games.' % bot.handle)
        elif success == -1:
            to_send.append('Not all rows were fetched due to slow query, you can use refresh or next to try and grab more soon.')
        
        return bot.qtell.send_list(usr, to_send)
    
    
    def mk_show(usr, first=False, offset_add=20):
        if not first:
            usr['query_offset'] += offset_add
        success, data = mk_query(usr, columns='games.ID as ID, white.handletext as white, black.handletext as black, whandle, wrating, brating, rated, variants.showtext as variant, result, end_time, time, inc, longresults.showtext as lresult', number=21, offset=usr['query_offset'])
        
        if not success:
            if not first:
                usr['query_offset'] -= offset_add
            return data
        
        if not data:
            if not first:
                usr['query_offset'] -= offset_add
            return bot.qtell(usr, 'There are no more games to show.')
        
        to_send = ['Games fitting your query, starting at game %s:' % (usr['query_offset']+1)]
        to_send.append('               white      Res      black          Typ          End Time')
        
        score = {1: '1-0', 0.5:'1/2', 0:'0-1'}
        rated = {1:'r', 0:'u'}
        for i, g in enumerate(data[:20]):
            to_send.append('%3s: %14s %4s %s %4s %-14s [%3s%s%3s %3s] %3s %s' % (str(i+1+usr['query_offset'])[-3:], str(g['white'])[:14], g['wrating'], score[g['result']], g['brating'], str(g['black'])[:14], g['variant'], rated[g['rated']], g['time'], g['inc'], g['lresult'], mk_servertime(g['end_time']).strftime('%m-%d %H:%M')))

        if len(data) == 21 or len(data) == 20 and success == -1:
            to_send.append('Use "tell %s next" to view more games.' % bot.handle)
        elif success == -1:
            to_send.append('Not all rows were fetched due to slow query, you can use refresh or next to try and grab more soon.')
        
        return bot.qtell.send_list(usr, to_send)
         
    
    @bot.deco_tell('next')
    def next(usr, args, tags):
        if usr['qtell_buffer']:
            return bot.qtell.send(usr)
        elif usr['query']:
            if usr['query_type'] == 'history':
                return mk_hist(usr)
            elif usr['query_type'] == 'show':
                return mk_show(usr)
            else:
                return bot.qtell(usr, 'You just found a bug.')
        else:
            return bot.qtell(usr, 'There is no more to show.')

    
    def get_to_fics(usr, g, save_to):
        """Put game on FICS and save it with save_to. IE: save_to='rcopy usr me'
        or save_to='jsave %01'
        """
        chess = set(['blitz', 'standard', 'lightning', 'untimed'])
        random = set(['wild/fr', 'wild/4', 'wild/3', 'wild/2', 'wild/1'])
        
        variant = g['variant']
        
        if variant in chess:
            variant = 'chess'
        
        if superexamine:
            if bot['users']['observatoer']['online']:
                if g['rated']:
                    bot.send('rmatch observatoer gamebot %s %s r %s' % (g['time'], g['inc'], variant.replace('/', ' ')))
                else:
                    bot.send('rmatch observatoer gamebot %s %s u %s' % (g['time'], g['inc'], variant.replace('/', ' ')))
                bot.send('accept observatoer')
                bot.send('abort')
            else:
                bot.send('bsetup b %s' % variant.replace('/', ' '))
        else:
            bot.send('bsetup b %s' % variant.replace('/', ' '))
        
        castle_wrong = False
        if variant in random:
            fen_info = g['startpos'].split()
            bot.send('bsetup fen %s' % fen_info[0])
            
            if fen_info[1] != '-':
                if 'KQ' in fen_info[2]:
                    bot.send('bsetup wcastle both')
                elif 'K' in fen_info[2]:
                    bot.send('bsetup wcastle kside')
                elif 'Q' in fen_info[2]:
                    bot.send('bsetup wcastle qside')
                
                if 'kq' in fen_info[2]:
                    bot.send('bsetup bcastle both')
                elif 'k' in fen_info[2]:
                    bot.send('bsetup bcastle kside')
                elif 'q' in fen_info[2]:
                    bot.send('bsetup bcastle qside')
            
                if variant == 'wild/fr':
                    # we need to find the rook and king files.
                    first_rook = fen_info[0].index('r')
                    bot.send('bsetup qrf %s' % chr(97+first_rook))
                    bot.send('bsetup kf %s' % chr(97+fen_info[0].index('k')))
                    bot.send('bsetup krf %s' % chr(97+fen_info[0].index('r', first_rook+1)))
                elif 'O-O' in g['moves']:
                    castle_wrong = True
        
        bot.send('bsetup done')
        bot.send('wname %s' % g['white'])
        bot.send('wrating %s' % g['wrating'])
        bot.send('bname %s' % g['black'])
        bot.send('brating %s' % g['brating'])
        
        spam = pgn.clk(0, 0, g.get('time', 0)*60, g.get('inc', 0), 1)[6:-1]
        bot.send('wclock %s' % spam)
        bot.send('bclock %s' % spam)
        
        w_used = 0
        b_used = 0
        
        g['moves'] = g['moves'].split()
        g['times'] = [float(t) for t in g['times'].split()]
        for i in xrange(len(g['moves'])):
            bot.send(g['moves'][i])
            if i % 2 == 0:
                w_used += g['times'][i]
                bot.send('wclock %s' % pgn.clk(g['times'][i], w_used, g.get('time', 0)*60, g.get('inc', 0), i//2 + 1)[6:-1])
            else:
                b_used += g['times'][i]
                bot.send('bclock %s' % pgn.clk(g['times'][i], b_used, g.get('time', 0)*60, g.get('inc', 0), i//2 + 1)[6:-1])
        
        if g['ficscode']:
            # Special case for losers:
            if g['ficscode'] == 2 and g['variant'] == 'losers':
                results = {1: '3 white', 0: '3 black'}
                bot.send('result %s' % results[g['result']])
            elif g['cneeded']:
                results = {1: '%s white' % g['ficscode'], 0: '%s black' % g['ficscode']}
                bot.send('result %s' % results[g['result']])
            else:
                bot.send('result %s' % g['ficscode'])
        else:
            results = {1: '45 white', 0: '45 black', 0.5: '40'}
            bot.send('result %s' % results[g['result']])
            
        bot.send('commit')
        bot.send('back 999')
        bot.send(save_to)
        bot.send('unexamin')
        
        return True, castle_wrong


    @bot.deco_tell('examine')
    def examine(usr, args, tags):
        """EXAMINE
        =======
        
        examine #. If you give anything more then the number. A new history will
        be created, and that used (also if you did not view a history before, it
        will do this, meaning you get your own history). # Must be an integer,
        negative integers are the same as positive.
        
        The offset can be bigger then 20, its just history output that is limited
        to that.
        """
        parsed = list(parse(args))
        args = copy.copy(parsed[0])
        if len(args) == 0:
            return bot.qtell(usr, 'You must give an integer as first/second argument. Only flagged or no arguments found.')
        elif len(args) == 1:
            try:
                game = abs(int(args[0]))
                parsed[0] = []
            except:
                return bot.qtell(usr, 'The argument %s is not an integer, and no other suitable argument found.' % args[0])
        else:
            for i, arg in enumerate(args):
                try:
                    game = abs(int(arg))
                    del parsed[0][i]
                    break
                except:
                    continue
            else:
                return bot.qtell(usr, 'You must pass game number/offset, ie. examine siggemannen 2 -v standard, etc.')
        
        
        if parsed[0] or parsed[1] or not usr['query']:
            setup = setup_query(usr, parsed=parsed)
            if setup != True:
                return setup

        if game == 0:
            return bot.qtell(usr, 'There is no 0th game.')

        offset = game - 1
        
        success, data = mk_query(usr, columns='games.ID as ID, end_time, white.handletext as white, black.handletext as black, wrating, brating, rated, FICSCODE as ficscode, CNEEDED as cneeded, varianttext as variant, result, start_time, time, inc, longresults.longresult as longresult, moves, times, startpos', number=1, offset=offset)
        if not success:
            return data
        
        if not data:
            return bot.qtell(usr, 'The is no game matching this query + offset.')
        g = data[0]
       
        spam, castle_wrong = get_to_fics(usr, g, 'rcopy %s %s' % (usr, bot.handle))
        if spam != True:
            return spam
       
        rateds = {0:'unrated', 1:'rated'}
        to_send = ['You should now be examining the game:']
        to_send.append('%s(%s) vs. %s(%s) %s %s %s %s game.' % (g['white'], g['wrating'], g['black'], g['brating'], g['time'], g['inc'], rateds[g['rated']], g['variant']))
        to_send.append('The game started on %s and ended as:' % mk_servertime(g['start_time']).strftime('%a %b %d, %H:%M %Z %Y'))
        to_send.append('    %s' % g['longresult'])
        if castle_wrong:
            to_send.append('Please note: There might be an error with castleing in this game.')
        
        return bot.qtell.send_list(usr, to_send)
        

    @bot.deco_tell('filljournal', lambda usr, tags: '*' in tags or 'SR' in tags or usr['handle'].lower() in bot_operators)
    def filljournal(usr, args, tags):
        """Fill the journal with the current games. It is always the next 25 games.
        if args is not empty, it is used to process the history. IE:
        filljournal siggemannen -v chess works. (as everything it overwrites
        the current history setting).
        As an extra argument an offset can be given, ie:
        filljournal 27 will skip the first 26 to fill the journal with the next
        26 games. (Similar as examin, only that it gives up to 26 games at once, 
        and that it defaults to start at first game, while examin always wants a
        number)
        """
        parsed = list(parse(args))
        args = copy.copy(parsed[0])
        if len(args) == 0:
            game = 1
        elif len(args) == 1:
            try:
                game = abs(int(args[0]))
                parsed[0] = []
            except:
                return bot.qtell(usr, 'The argument %s is not an integer, and no other suitable argument found.' % args[0])
        else:
            for i, arg in enumerate(args):
                try:
                    game = abs(int(arg))
                    del parsed[0][i]
                    break
                except:
                    continue
            else:
                return bot.qtell(usr, 'You must pass game number/offset, ie. filljournal siggemannen 2 -v standard, etc.')
        
        
        if parsed[0] or parsed[1] or not usr['query']:
            setup = setup_query(usr, parsed=parsed)
            if setup != True:
                return setup

        if game == 0:
            return bot.qtell(usr, 'There is no 0th game.')

        offset = game - 1
        
        success, data = mk_query(usr, columns='games.ID as ID, end_time, white.handletext as white, black.handletext as black, wrating, brating, rated, FICSCODE as ficscode, CNEEDED as cneeded, varianttext as variant, result, start_time, time, inc, longresults.longresult as longresult, moves, times, startpos', number=26, offset=offset)
        if success == False:
            return data
        if not data:
            return bot.qtell(usr, 'There were no games.')
        
        if success != -1:
            to_send = ['The games were stored into the journal.']
        else:
            to_send = ['Due to slow selection, only %s games were stored.' % len(data)]
        i = 0
        for i, g in enumerate(data):
            spam, castle_wrong = get_to_fics(usr, g, 'jsave %%%s' % (i+1))
            if spam != True:
                to_send.append('There was an error with game %s, its variant is not supported.' % i)
            if castle_wrong:
                to_send.append('There might be wrong castleing in game %s, making it invalid.' % i)
        
        for j in xrange(i+1, 26):
            bot.send('jkill %%%s' % (j+1))
       
        return bot.qtell.send_list(usr, to_send)
    
    
    @bot.deco_tell('clearjournal', lambda usr, tags: '*' in tags or 'SR' in tags or usr['handle'].lower() in bot_operators)
    def clearjournal(usr, args, tags):
        """clearjounral clears my journal completely.
        """
        for j in xrange(0, 26):
            bot.send('jkill %%%s' % (j+1))
        
        return bot.qtell(usr, 'My journal was cleared.')
       


    ### CLEARING OUT THE DAMN PGN FOLDER JUST IN CASE:    
    for f in os.listdir('pgns'):
        os.remove('pgns'+os.sep+f)


    @bot.deco_tell('pgn', lambda usr, tags: usr['handle'].lower() in bot_operators)
    def export_pgn(usr, args, tags):
        """PGN
        ===
        pgn n. This saves n (max. 1000) games from the current history view into
        a zipped pgn file and makes it available for download.
        
        The only flag you can give is -c clk (default), -c emt or -c to toggle
        %clk timestamps, %emt timestamps or no timestamps.
        
        If you would like a pgn with more games, please talk to one of the operators
        so they can ask me to create it for you, or even do some more complex
        queries for you.
        """
        if 'U' in tags:
            return bot.qtell(usr, 'Sorry but guests are not allowed to use this command.')
        parsed = parse(args)
        if len(parsed[0]) > 0:
            try:
                num = int(parsed[0][0])
            except:
                return bot.qtell(usr, '%s is not a correct number.' % parsed[0][0])
            if num < 1:
                return bot.qtell(usr, 'Can\'t export less then 1 game, smartass.')
            if num > 1000 and ('*' in tags or 'SR' in tags or usr['handle'].lower() in bot_operators):
                num = 1000
                to_send = ['Specified number greater then 1000 defaulting to 1000. Talk to a bot operator if you need a bigger export.']
            else:
                to_send = []
        
        
        clocks = {None: pgn.clk, 'clk': pgn.clk, 'emt': pgn.emt, 'none': None}
        
        to_send = []
        if parsed[1].has_key('c') and len(parsed[1]['c']) > 0:
            if parsed[1]['c'][0].lower() in clocks:
                clock = clocks[parsed[1]['c'][0].lower()]
            else:
                to_send.append('Invalid clock setting "%s", defaulting to %clk info.' % parsed[1]['c'])
                clock = pgn.clk
        else:
            clock = pgn.clk
        
        if not usr['query']:
            return bot.qtell(usr, 'You do not history/show command executed. Please do this first.')
        
        if usr['current_pgn_export'] is not None:
            if usr['current_pgn_export'].isAlive():
                return bot.qtell(usr, 'You have a pgn export in progress. Cannot start another one!')
            
            if usr['current_pgn_export'].blocked_until > time.time() and not ('*' in tags or 'SR' in tags or usr['handle'].lower() in bot_operators):
                return bot.qtell(usr, 'Sorry, but you will have to wait another %3.2f seconds to avoid overloading the server.' % (usr['current_pgn_export'].blocked_until - time.time()))
        
        from threading import Thread
        import zipfile
        class pgnmaker(Thread):
            def __init__(self, usr, number, sender):
                Thread.__init__(self)
                self.usr = usr
                self.number = number
                self.sender = sender
            
            def run(self):
                t = time.time()
                success, data = mk_query(self.usr, columns='games.ID as ID, end_time, white.handletext as white, black.handletext as black, wrating, brating, rated, varianttext as variant, result, start_time, time, inc, longresults.longresult as longresult, moves, times, startpos', number=self.number, ignore_time_limit=True)
                if not success:
                    return data
                
                pgns = []
                for g in data:
                    rated = 'rated' if g['rated'] else 'unrated'
                    
                    g['event'] = 'FICS %s %s game' % (rated, g['variant'])
                    g['start_time'] = mk_servertime(g['start_time'])
                    g['fen'] = g['startpos']
                    
                    pgns.append(pgn.make_pgn(g, format_time=clock, max_width=80))
                
                pgns = '\n\n\n'.join(pgns)
                
                z = zipfile.ZipFile('pgns'+os.sep+usr['handle'].lower()+'.zip', 'w', compression=zipfile.ZIP_DEFLATED)
                
                z.writestr(usr['handle'].lower()+'.pgn', pgns)
                
                z.close()
                self.sender('tell %s Your pgn file has been created please download at .../%s.zip\n' % (usr['handle'], usr['handle'].lower()))
                
                self.blocked_until = time.time() + (time.time() - t) * 10
                
                del self.usr
                del self.number
                del self.sender

        u = usr.copy() 
        make = pgnmaker(u, num, bot.send)
        make.start()
        
        usr['current_pgn_export'] = make
                
        def delete_pgn(name):
            os.remove('pgns'+os.sep+name)
        
        bot.timer(time.time()+3600, delete_pgn, usr['handle'].lower()+'.zip')
        
        return bot.qtell.send_list(usr, to_send + ['The pgn is being created, you will recieve a private tell when it is finished.', 'The pgn will be deleted automatically in 60 minutes.'])
        

    @bot.deco_tell('printpgn')
    def print_pgn(usr, args, tags):
        """PRINTPGN
        ========
        printpgn #. Print the games pgn. Please note that there is no way to print it
        on FICS without the starting colons. You will have to remove them yourself.
        As default, no move times are given, however you can change this behavior
        with:
            o -c (or -c clk) (adds [%clk ...] tags that give the current clock)
            o -c emt (adds [%emt ...] elapsed move time tags)
        A combination of both is not possible.
        """
        # COPY PASTED FROM examine mostly.
        parsed = list(parse(args))
        args = copy.copy(parsed[0])
        if len(args) == 0:
            return bot.qtell(usr, 'You must give an integer as first/second argument. Only flagged or no arguments found.')
        elif len(args) == 1:
            try:
                game = abs(int(args[0]))
                parsed[0] = []
            except:
                return bot.qtell(usr, 'The argument %s is not an integer, and no other suitable argument found.' % args[0])
        else:
            for i, arg in enumerate(args):
                try:
                    game = abs(int(arg))
                    del parsed[0][i]
                    break
                except:
                    continue
            else:
                return bot.qtell(usr, 'You must pass game number/offset, ie. pgn siggemannen 2 -v standard, etc.')
        
        # INSERT:
        
        clocks = {None: pgn.clk, 'clk': pgn.clk, 'emt': pgn.emt}
        
        to_send = []
        if parsed[1].has_key('c'):
            if len(parsed[1]['c']) > 0:
                if parsed[1]['c'][0] in clocks:
                    clock = clocks[parsed[1]['c'][0]]
                else:
                    to_send = ['Invalid clock setting "%s", defaulting to no clock info.' % parsed[1]['c']]
                    clock = None
            else:
                clock = clocks[None]
            del parsed[1]['c']
        else:
            clock = None
        
        
        if parsed[0] or parsed[1] or not usr['query']:
            setup = setup_query(usr, parsed=parsed)
            if setup != True:
                return setup

        if game == 0:
            return bot.qtell(usr, 'There is no 0th game.')

        offset = game - 1
        
        success, data = mk_query(usr, columns='games.ID as ID, end_time, white.handletext as white, black.handletext as black, wrating, brating, rated, varianttext as variant, result, start_time, time, inc, longresults.longresult as longresult, moves, times, startpos', number=1, offset=offset)
        if not success:
            return data
        
        if not data:
            return bot.qtell(usr, 'The is no game matching this query + offset.')
        g = data[0]
        # COPY PASTE END
        
        rated = 'rated' if g['rated'] else 'unrated'
        
        g['event'] = 'FICS %s %s game' % (rated, g['variant'])
        g['start_time'] = mk_servertime(g['start_time'])
        g['fen'] = g['startpos']
        
        data = pgn.make_pgn(g, format_time=clock, max_width=78)
        
        return bot.qtell(usr, data, use_next=False)        


    @bot.deco_tell('gstats')
    def gstats(usr, args, tags):
        """gstat shows the amount of games stored for each variant, as well as
        totally.
        Normally all variants with less then 0.005 % are grouped together as
        Other. To get a complete list, use -a flag.
        
        As opposed to my fingernote one, this total number includes bughouse games
        which are not saved but only counted. One bughouse game means both boards,
        bughouse games are also counted if they are guest games, while normal
        games are not.
        
        The servers gstat command is very useful if you want a real count for all
        server games.
        """
        args = args.split()
        show_all = ('-a' in args)
        
        data = db.select('SELECT varianttext as var, count FROM variants ORDER BY count DESC')
        to_send = []
        total = 0
        
        data = list(data)
        
        bug = 0
        guest = 0
        for var in data:
            if var['var'] == 'bughouse':
                var['count'] = var['count']//2
                bug = var['count']
            if var['var'] == 'guestgames':
                guest = var['count']
                var['var'] = 'Games with guests'
            total += var['count']

        if not show_all:
            other = 0            
            for var in data:
                if var['count']*100.0/total < 0.005:
                    other += var['count']
                    var['count'] = 0

        data.sort(lambda x, y: (x['count'] < y['count'])*2-1)

        if not show_all:
            data.append({'var': 'Other', 'count': other})
        
        to_send = ['Total Games counted: %s' % (formatlargeint(total))]
        to_send.append('Total Games stored:  %s' % (formatlargeint(total-bug-guest)))
        to_send.append('+---------------------------------------------------+')        
        to_send.append('| Variant              |       # games | % of total |')
        to_send.append('+----------------------+---------------+------------+')
        # update note 1 for fun of it:
        update_finger()
        for var in data:
            if var['count'] == 0:
                continue
            to_send.append('| %-20s |%14s |%9s %% |' % (var['var'][:20], formatlargeint(var['count']), '%2.3f' % (var['count']*100.0/total)))
            if var['var'] == 'bughouse' or var['var'] == 'Games with guests':
                to_send[-1] = to_send[-1] + ' (not stored)'
        to_send.append('+---------------------------------------------------+')        
        return bot.qtell.send_list(usr, to_send)
    
    
    @bot.deco_tell('fen')
    def get_fen(usr, args, tags):
        """FEN
        ===
        This command prints a fen for a being played or observed (not your own game).
        To use it, just just give the handle or game number. For example:
            o fen
            o fen Ludens
            o fen 123
        
        The fen will give the complete fen information. The only thing it will not
        give is information about rook files (X-Fen) which means that fiew wild/fr
        position may be lacking exact castleing information.
        
        Note: FICS "bsetup fen ..." command only supports fen up to the colour field.
            The rest must be set with other bsetup commands.
        """
        args = args.split()
        if len(args) < 1:
            args = [usr['handle']]
        bot.execute('observe %s' % args[0], fen_gotten, usr, args[0])
        bot.send('unobserve')
    
    
    def fen_gotten(data, usr, arg):
        d = style12(data)
        
        if not d:
            return bot.qtell(usr, 'Sorry, but the game/user "%s" seems to be invalid or not playing a game.' % arg)
        hl = usr['handle'].lower()
        if d['relation'][1] == 'played' and (hl == d['white'].lower() or hl == d['black'].lower()):
            return bot.qtell(usr, 'Sorry, but I don\'t give fens for games you are playing.')
        
        return bot.qtell(usr, 'FEN: %s' % d['fen'])
    
    
    @bot.deco_tell('die', lambda usr, tags: '*' in tags or 'SR' in tags or usr['handle'].lower() in bot_operators)
    def die(usr, args, tags):
        """die will kill the bot permanently
        """
        print 'Recieved die from %s.' % usr['handle']
        db.conn.close()
        sys.exit()
        return bot.qtell('%s is not a correct number.' % parsed[0][0])
    
    
    @bot.deco_tell('restart', lambda usr, tags: '*' in tags or 'SR' in tags or usr['handle'].lower() in bot_operators)
    def restart(usr, args, tags):
        """restart will have the bot log out, restart and come back.
        That is, it won't actually reload the code, but everything else should
        be reset.
        """
        print 'Recieved restart from %s.' % usr['handle']
        db.conn.close()
        bot.close()
    
    
    @bot.deco_tell('ping4711', lambda usr, tags: usr['handle'].lower() in bot_operators)
    def ping(usr, args, tags):
        if len(args) == 0:
        	bot.send('tell %s pong4712' % usr)              	
    
          
    try:
        bot.connect('gamebot', 'sdghsdf(39k.C')
    except icsbot.InvalidLogin, msg:
        print msg
        if str(msg) == 'Handle in use.':
            print 'Restarting'
            time.sleep(3)
            continue
        print 'Quitting.'
        break
    except icsbot.ConnectionClosed, msg:
        print 'Connection was lost, because:', msg
        print 'Restarting'
        time.sleep(3)
        continue
    except icsbot.socket.error, msg:
        print 'Socket error:', msg
        print 'Restarting'
        time.sleep(3)
        continue
    
    print 'Connected to FICS.'
    
    try:
        bot.run()
    except icsbot.ConnectionClosed, msg:
        if str(msg) == 'Someone logged in as me.':
            print 'Connection was lost, because someone logged in as me.'
            print 'Quitting.'
            break
        print 'Connection was lost, because:', msg
        print 'Restarting'
    except icsbot.socket.error, msg:
        print 'Socket error:', msg
        print 'Restarting'
    
    time.sleep(3)
